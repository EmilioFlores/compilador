class TrieNode {
public:
    TrieNode *abc[62];
    bool termina;
    int varNo;
    TrieNode();
};