
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 1 "parser.y"

#include <cstdio>
#include <iostream>
#include <string.h>
#include "cuadruplo.cpp"
//#include "estructura.cpp"
#include <stack>
#include <string>     // std::string, std::to_string
#include <vector>
#include <sstream>

#include <math.h> 
#include "prototipos.h"
#include "definiciones.h"
#include "memoria.cpp"
#include "dirProcedimientos.cpp"

using namespace std;

// stuff from flex that bison needs to know about:
extern "C" int yylex();
extern "C" int yyparse();
extern char * yytext;
extern "C" FILE *yyin;
extern int line_num;

 
const bool debug = false;






extern Memoria memoria; 



dirProcedimientos dirProcedimientos ;





string yyTipo = "";
string objetoNombre = "default";
string metodoNombre = "";
string funcionNombre = "";





int offsetGlobales[4] = { 0, 1000, 2000, 3000 };
int offsetTemporales[4] = {4000, 5000, 6000, 7000};
int offsetConstantes[4] = {8000, 9000, 10000, 11000};
int offsetDirObjetos[4] = {12000, 13000, 14000, 15000};
int offsetDirFunciones[4] = {16000, 17000, 18000, 19000};

int indexGlobales[4] = {0};
int indexTemporales[4] = {0};
int indexConstantes[4] = {0};
int indexDirObjetos[4] = {0};
int indexDirFunciones[4] = {0};



int indexParametro = 0;

bool metodo = false;
bool global = true;
bool objeto = false;
bool temporal = false;
bool funcion = false; 

stack<int> pilaOperandos;
stack<string> pilaOperadores;
stack<int> pilaTipos;
stack<int> pilaSaltos;
stack<int> pilaSUB;

vector<Cuadruplo> cuadruplos; 
vector<constante> constantesEnteras;
vector<constante> constantesDecimales;
vector<constante> constantesTexto;
vector<constante> constantesBandera;

int cuboSemantico[4][4][13] = 	{
								  	{  // bandera 0
                                        //  0     1     2     3     4     5     6     7     8     9    10    11     12
                                        //  +     -     *     /    ==    !=     >     <     =    >=    <=    ||     &&
                                        {  -1  , -1  , -1  , -1  ,  0  ,  0  ,  0  ,  0  ,  0  ,  0  ,  0  ,  0  ,  0   },  // bandera 0
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1   },  // entero  1
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1   },  // decimal 2
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1   },  // texto   3
                                    }, 

                                    {   // entero 1  
                                        //  0     1     2     3     4     5     6     7     8     9    10    11     12
                                        //  +     -     *     /    ==    !=     >     <     =    >=    <=    ||     &&
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1   },  // bandera 0
                                        {   1  ,  1  ,  1  ,  2  ,  0  ,  0  ,  0  ,  0  ,  1  ,  0  ,  0  , -1  , -1   },  // entero  1
                                        {   2  ,  2  ,  2  ,  2  ,  0  ,  0  ,  0  ,  0  ,  1  ,  0  ,  0  , -1  , -1   },  // decimal 2
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1   },  // texto   3
                                    },

                                    {   // decimal 2
                                        //  0     1     2     3     4     5     6     7     8     9    10    11     12
                                        //  +     -     *     /    ==    !=     >     <     =    >=    <=    ||     &&
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  ,  -1  },  // bandera 0
                                        {   2  ,  2  ,  2  ,  2  ,  0  ,  0  ,  0  ,  0  ,  2  ,  0  ,  0  , -1  ,  -1  },  // entero  1
                                        {   2  ,  2  ,  2  ,  2  ,  0  ,  0  ,  0  ,  0  ,  2  ,  0  ,  0  , -1  ,  -1  },  // decimal 2
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  ,  -1  },  // texto   3
                                    },  

                                    {   // texto 3
                                        //  0     1     2     3     4     5     6     7     8     9    10    11     12
                                        //  +     -     *     /    ==    !=     >     <     =    >=    <=    ||     &&
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  ,  -1  },  // bandera 0
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  ,  -1  },  // entero  1
                                        {  -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  , -1  ,  -1  },  // decimal 2
                                        {  -1  , -1  , -1  , -1  ,  0  ,  0  , -1  , -1  ,  3  , -1  , -1  , -1  ,  -1  },  // texto   3
                                    }   
                              	};

//dirProcedimientos dirProcs; 



/* Line 189 of yacc.c  */
#line 203 "parser.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ENTERO = 258,
     DECIMAL = 259,
     TEXTO = 260,
     NUMBER = 261,
     IDENTIFICADOR = 262,
     BANDERA = 263,
     PLUS = 264,
     MINUS = 265,
     TIMES = 266,
     SLASH = 267,
     LPAREN = 268,
     RPAREN = 269,
     LCURLY = 270,
     RCURLY = 271,
     LBRACKET = 272,
     RBRACKET = 273,
     SEMICOLON = 274,
     COMMA = 275,
     DOT = 276,
     EQL = 277,
     EQLEQL = 278,
     NEQ = 279,
     COLON = 280,
     LSS = 281,
     GTR = 282,
     LSSOEQL = 283,
     GTROEQL = 284,
     OR = 285,
     AND = 286,
     CONDICIONSYM = 287,
     PROGRAMASYM = 288,
     FALLOSYM = 289,
     VARSYM = 290,
     MUESTRASYM = 291,
     MUESTRALINEASYM = 292,
     LEESYM = 293,
     BANDERASYM = 294,
     CARACTERSYM = 295,
     ENTEROSYM = 296,
     GRANENTEROSYM = 297,
     DECIMALSYM = 298,
     TEXTOSYM = 299,
     ARREGLOSYM = 300,
     MATRIZSYM = 301,
     CICLOSYM = 302,
     HAZSYM = 303,
     MIENTRASSYM = 304,
     FUNCIONSYM = 305,
     REGRESASYM = 306,
     INCLUIRSYM = 307,
     OBJETOSYM = 308,
     PRIVADOSYM = 309,
     PUBLICOSYM = 310
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 135 "parser.y"

	int ival;
	float fval;
	char *sval;
	bool bval;



/* Line 214 of yacc.c  */
#line 303 "parser.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 315 "parser.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  6
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   268

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  56
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  103
/* YYNRULES -- Number of rules.  */
#define YYNRULES  157
/* YYNRULES -- Number of states.  */
#define YYNSTATES  283

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   310

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     8,    10,    11,    20,    26,    28,    34,
      36,    39,    44,    46,    47,    49,    51,    52,    53,    54,
      65,    67,    68,    69,    70,    81,    83,    85,    87,    89,
      91,    93,    97,   101,   102,   103,   109,   111,   114,   116,
     117,   118,   124,   126,   129,   131,   132,   133,   138,   140,
     141,   146,   148,   153,   157,   159,   165,   169,   171,   172,
     177,   179,   181,   183,   185,   187,   189,   191,   192,   197,
     198,   203,   205,   206,   211,   213,   214,   215,   221,   224,
     227,   229,   231,   233,   235,   237,   239,   241,   243,   245,
     246,   250,   251,   255,   256,   260,   262,   263,   267,   268,
     272,   273,   277,   279,   280,   281,   287,   291,   293,   295,
     297,   301,   303,   305,   307,   309,   311,   313,   317,   319,
     323,   325,   326,   327,   334,   338,   340,   341,   346,   347,
     355,   356,   360,   362,   363,   364,   365,   366,   367,   368,
     384,   385,   393,   395,   397,   398,   405,   406,   413,   414,
     419,   421,   422,   427,   429,   432,   433,   437
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      57,     0,    -1,    63,    58,    66,   156,    -1,    59,    -1,
      -1,    53,     7,    60,    15,    61,    62,    16,    19,    -1,
      54,    15,   128,    66,    16,    -1,   158,    -1,    55,    15,
     127,    67,    16,    -1,   158,    -1,    64,    65,    -1,    52,
      26,     7,    27,    -1,    64,    -1,    -1,    68,    -1,    72,
      -1,    -1,    -1,    -1,    50,    76,    69,     7,    70,    77,
      94,    19,    71,    68,    -1,   158,    -1,    -1,    -1,    -1,
      50,    76,    73,     7,    74,    78,    94,    19,    75,    72,
      -1,   158,    -1,    41,    -1,    43,    -1,    44,    -1,    39,
      -1,     7,    -1,    13,    79,    14,    -1,    13,    83,    14,
      -1,    -1,    -1,    76,    80,     7,    81,    82,    -1,   158,
      -1,    20,    79,    -1,   158,    -1,    -1,    -1,    76,    84,
       7,    85,    86,    -1,   158,    -1,    20,    83,    -1,   158,
      -1,    -1,    -1,    88,   108,    89,    90,    -1,   158,    -1,
      -1,    20,   108,    91,    90,    -1,   158,    -1,    15,   127,
      93,    16,    -1,    98,    19,    93,    -1,   158,    -1,    15,
     127,    95,    96,    16,    -1,    98,    19,    95,    -1,   158,
      -1,    -1,    51,   108,    97,    19,    -1,   158,    -1,   105,
      -1,   135,    -1,   139,    -1,   148,    -1,   155,    -1,    99,
      -1,    -1,     7,   100,   101,   103,    -1,    -1,    21,     7,
     102,   101,    -1,   158,    -1,    -1,    13,   104,    87,    14,
      -1,   158,    -1,    -1,    -1,     7,   106,    22,   107,   108,
      -1,   111,   109,    -1,   110,   111,    -1,   158,    -1,    26,
      -1,    27,    -1,    23,    -1,    24,    -1,    28,    -1,    29,
      -1,    31,    -1,    30,    -1,    -1,   116,   112,   113,    -1,
      -1,     9,   114,   111,    -1,    -1,    10,   115,   111,    -1,
     158,    -1,    -1,   121,   117,   118,    -1,    -1,    11,   119,
     116,    -1,    -1,    12,   120,   116,    -1,   158,    -1,    -1,
      -1,    13,   122,   108,   123,    14,    -1,   124,   126,   125,
      -1,     9,    -1,    10,    -1,   158,    -1,    17,   108,    18,
      -1,   158,    -1,    99,    -1,     3,    -1,     8,    -1,     5,
      -1,     4,    -1,   129,    19,   127,    -1,   158,    -1,   133,
      19,   128,    -1,   158,    -1,    -1,    -1,    35,    76,   130,
       7,   131,   132,    -1,    17,   108,    18,    -1,   158,    -1,
      -1,    35,    76,   134,     7,    -1,    -1,    32,    13,   108,
      14,   136,    92,   137,    -1,    -1,    34,   138,    92,    -1,
     158,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,   140,
      13,   147,    20,   141,   108,   142,    20,   143,   147,   144,
      14,   145,    92,    -1,    -1,    48,   146,    92,    49,    13,
     108,    14,    -1,   105,    -1,   158,    -1,    -1,    36,    13,
     108,   149,   151,    14,    -1,    -1,    37,    13,   108,   150,
     153,    14,    -1,    -1,    20,   108,   152,   151,    -1,   158,
      -1,    -1,    20,   108,   154,   153,    -1,   158,    -1,    38,
       7,    -1,    -1,    33,   157,    92,    -1,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   221,   221,   223,   225,   225,   236,   237,   239,   240,
     244,   245,   246,   246,   251,   252,   254,   254,   259,   254,
     266,   268,   268,   274,   268,   279,   282,   283,   284,   285,
     286,   289,   290,   292,   292,   292,   297,   298,   299,   301,
     301,   301,   307,   308,   309,   312,   326,   312,   329,   331,
     331,   334,   341,   342,   343,   346,   352,   353,   354,   354,
     357,   360,   361,   362,   363,   364,   365,   368,   368,   389,
     389,   395,   396,   396,   414,   431,   449,   431,   460,   461,
     462,   464,   465,   466,   467,   468,   469,   470,   471,   473,
     473,   474,   474,   478,   478,   481,   483,   483,   484,   484,
     487,   487,   490,   492,   492,   492,   493,   494,   495,   496,
     497,   498,   502,   506,   510,   514,   518,   528,   529,   530,
     531,   535,   535,   535,   550,   551,   554,   554,   564,   564,
     567,   567,   571,   575,   577,   579,   581,   583,   585,   575,
     590,   590,   595,   596,   598,   598,   599,   599,   601,   601,
     602,   604,   604,   605,   608,   610,   610,   616
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ENTERO", "DECIMAL", "TEXTO", "NUMBER",
  "IDENTIFICADOR", "BANDERA", "PLUS", "MINUS", "TIMES", "SLASH", "LPAREN",
  "RPAREN", "LCURLY", "RCURLY", "LBRACKET", "RBRACKET", "SEMICOLON",
  "COMMA", "DOT", "EQL", "EQLEQL", "NEQ", "COLON", "LSS", "GTR", "LSSOEQL",
  "GTROEQL", "OR", "AND", "CONDICIONSYM", "PROGRAMASYM", "FALLOSYM",
  "VARSYM", "MUESTRASYM", "MUESTRALINEASYM", "LEESYM", "BANDERASYM",
  "CARACTERSYM", "ENTEROSYM", "GRANENTEROSYM", "DECIMALSYM", "TEXTOSYM",
  "ARREGLOSYM", "MATRIZSYM", "CICLOSYM", "HAZSYM", "MIENTRASSYM",
  "FUNCIONSYM", "REGRESASYM", "INCLUIRSYM", "OBJETOSYM", "PRIVADOSYM",
  "PUBLICOSYM", "$accept", "programa", "Objetos", "Objeto", "$@1",
  "AtributosPrivados", "AtributosPublicos", "Librerias", "Libreria",
  "Libreria1", "Funciones", "FuncionesObjetos", "Funcion", "$@2", "$@3",
  "$@4", "FuncionObjeto", "$@5", "$@6", "$@7", "Tipo", "Params",
  "ParamsObjeto", "Param", "$@8", "$@9", "Param1", "ParamObjeto", "$@10",
  "$@11", "ParamObjeto1", "Args", "$@12", "$@13", "Args1", "$@14",
  "Bloque", "Bloque1", "BloqueFuncion", "BloqueFuncion1", "BloqueFuncion2",
  "$@15", "Estatuto", "Llamada", "$@16", "Llamada1", "$@17", "Llamada2",
  "$@18", "Asignacion", "$@19", "$@20", "Expresion", "Expresion1",
  "Expresion2", "Exp", "$@21", "Exp1", "$@22", "$@23", "Termino", "$@24",
  "Termino1", "$@25", "$@26", "Factor", "$@27", "$@28", "Factor1",
  "Factor2", "VarCteExp", "Variables", "VariablesObjetos", "Variable",
  "$@29", "$@30", "Variable1", "VariableObjeto", "$@31", "Condicion",
  "$@32", "Condicion1", "$@33", "Ciclo", "$@34", "$@35", "$@36", "$@37",
  "$@38", "$@39", "$@40", "Ciclo1", "Escritura", "$@41", "$@42",
  "EstatutosSalida", "$@43", "EstatutosSalidaLinea", "$@44", "Lectura",
  "Main", "$@45", "epsilon", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    56,    57,    58,    60,    59,    61,    61,    62,    62,
      63,    64,    65,    65,    66,    67,    69,    70,    71,    68,
      68,    73,    74,    75,    72,    72,    76,    76,    76,    76,
      76,    77,    78,    80,    81,    79,    79,    82,    82,    84,
      85,    83,    83,    86,    86,    88,    89,    87,    87,    91,
      90,    90,    92,    93,    93,    94,    95,    95,    97,    96,
      96,    98,    98,    98,    98,    98,    98,   100,    99,   102,
     101,   101,   104,   103,   103,   106,   107,   105,   108,   109,
     109,   110,   110,   110,   110,   110,   110,   110,   110,   112,
     111,   114,   113,   115,   113,   113,   117,   116,   119,   118,
     120,   118,   118,   122,   123,   121,   121,   124,   124,   124,
     125,   125,   126,   126,   126,   126,   126,   127,   127,   128,
     128,   130,   131,   129,   132,   132,   134,   133,   136,   135,
     138,   137,   137,   140,   141,   142,   143,   144,   145,   139,
     146,   139,   147,   147,   149,   148,   150,   148,   152,   151,
     151,   154,   153,   153,   155,   157,   156,   158
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     4,     1,     0,     8,     5,     1,     5,     1,
       2,     4,     1,     0,     1,     1,     0,     0,     0,    10,
       1,     0,     0,     0,    10,     1,     1,     1,     1,     1,
       1,     3,     3,     0,     0,     5,     1,     2,     1,     0,
       0,     5,     1,     2,     1,     0,     0,     4,     1,     0,
       4,     1,     4,     3,     1,     5,     3,     1,     0,     4,
       1,     1,     1,     1,     1,     1,     1,     0,     4,     0,
       4,     1,     0,     4,     1,     0,     0,     5,     2,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       3,     0,     3,     0,     3,     1,     0,     3,     0,     3,
       0,     3,     1,     0,     0,     5,     3,     1,     1,     1,
       3,     1,     1,     1,     1,     1,     1,     3,     1,     3,
       1,     0,     0,     6,     3,     1,     0,     4,     0,     7,
       0,     3,     1,     0,     0,     0,     0,     0,     0,    15,
       0,     7,     1,     1,     0,     6,     0,     6,     0,     4,
       1,     0,     4,     1,     2,     0,     3,     0
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,    13,     0,     1,     0,   157,     3,
      12,    10,     0,     4,     0,     0,    14,    20,    11,     0,
      30,    29,    26,    27,    28,    16,   155,     2,   157,     0,
       0,     0,   157,     7,    17,   157,   156,   157,     0,     0,
       9,     0,     0,   157,     0,   118,     0,   157,     0,   120,
     157,     0,   157,     0,   121,    67,     0,     0,     0,     0,
     133,   140,     0,     0,    66,    61,    62,    63,    64,    65,
      54,   157,   126,     0,   157,   157,     5,    33,     0,    36,
     157,     0,     0,   157,     0,   157,   157,   157,   154,     0,
       0,    52,   157,   117,     0,     6,   119,     0,     0,    15,
      25,     0,    31,   157,    18,   122,     0,   157,    71,    76,
     107,   108,   103,     0,   157,    89,    96,     0,   109,   144,
     146,   157,     0,    53,   127,    21,     8,    34,   157,     0,
      57,   157,   157,    69,    72,    68,    74,   157,   157,   128,
      83,    84,    81,    82,    85,    86,    88,    87,    78,   157,
      80,   157,   157,   113,   116,   115,    67,   114,   112,   157,
     157,   157,    75,   142,     0,   143,     0,     0,   157,   157,
       0,    60,   157,    19,   157,   123,   125,   157,    45,    77,
     104,     0,    79,    91,    93,    90,    95,    98,   100,    97,
     102,   157,   106,   111,   157,     0,   150,   157,     0,   153,
     134,   157,    22,   157,    35,    38,    58,    55,    56,     0,
      70,     0,   157,    48,     0,   157,   157,   157,   157,   157,
       0,   148,   145,   151,   147,   157,     0,     0,    37,     0,
     124,    73,    46,   105,   130,   129,   132,    92,    94,    99,
     101,   110,   157,   157,   135,   141,   157,     0,    59,   157,
       0,   149,   152,     0,    39,     0,    42,     0,   157,    47,
      51,   131,   136,     0,    32,    23,    49,   157,    40,   157,
     157,   137,   157,    24,    50,     0,   157,    41,    44,   138,
      43,     0,   139
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     8,     9,    19,    32,    39,     3,     4,    11,
      15,    98,    16,    29,    41,   131,    99,   167,   227,   269,
      77,    53,   247,    78,   101,   168,   204,   255,   263,   272,
     277,   211,   212,   249,   259,   270,    36,    62,    81,   128,
     170,   229,    63,    64,    83,   107,   177,   135,   178,    65,
      84,   137,   113,   148,   149,   114,   151,   185,   216,   217,
     115,   152,   189,   218,   219,   116,   138,   214,   117,   192,
     159,    43,    47,    44,    82,   132,   175,    48,    94,    66,
     181,   235,   250,    67,    89,   225,   253,   267,   275,   281,
      90,   164,    68,   160,   161,   195,   242,   198,   243,    69,
      27,    30,   118
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -186
static const yytype_int16 yypact[] =
{
     -37,     2,    25,   -23,   -37,    30,  -186,    31,    -9,  -186,
    -186,  -186,    22,  -186,     4,    20,  -186,  -186,  -186,    39,
    -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,     1,    49,
      44,    45,    10,  -186,  -186,    29,  -186,    33,    54,    57,
    -186,    63,     4,    14,    58,  -186,     4,    -9,    59,  -186,
      29,    60,     4,    65,  -186,    61,    68,    69,    72,    79,
    -186,  -186,    75,    71,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,    29,  -186,    77,    33,    38,  -186,  -186,    82,  -186,
      29,    88,   101,    89,    87,    13,    13,    13,  -186,    99,
      44,  -186,    14,  -186,   108,  -186,  -186,     4,   100,  -186,
    -186,   111,  -186,    14,  -186,  -186,   112,   109,  -186,  -186,
    -186,  -186,  -186,   113,    74,  -186,  -186,     9,  -186,  -186,
    -186,   118,    80,  -186,  -186,  -186,  -186,  -186,    83,   107,
    -186,    -9,   114,  -186,  -186,  -186,  -186,    13,    13,  -186,
    -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,    13,
    -186,    -1,     7,  -186,  -186,  -186,  -186,  -186,  -186,   116,
     110,   115,  -186,  -186,   117,  -186,   123,   121,   119,    13,
     122,  -186,    14,  -186,    13,  -186,  -186,    89,   126,  -186,
    -186,    44,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,    13,  -186,  -186,    13,   127,  -186,    13,   128,  -186,
    -186,    13,  -186,     4,  -186,  -186,  -186,  -186,  -186,   129,
    -186,   132,    13,  -186,   135,   120,    13,    13,    13,    13,
     137,  -186,  -186,  -186,  -186,    13,   136,   143,  -186,   138,
    -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,  -186,   110,   115,  -186,  -186,     4,    65,  -186,   139,
      44,  -186,  -186,   142,  -186,   144,  -186,   146,    13,  -186,
    -186,  -186,  -186,   156,  -186,  -186,  -186,   118,  -186,    38,
     139,  -186,   147,  -186,  -186,   152,     4,  -186,  -186,  -186,
    -186,    44,  -186
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,   164,  -186,
     124,  -186,    41,  -186,  -186,  -186,   -96,  -186,  -186,  -186,
     -10,  -186,  -186,   -29,  -186,  -186,  -186,  -101,  -186,  -186,
    -186,  -186,  -186,  -186,   -94,  -186,   -89,    85,   -68,     8,
    -186,  -186,   -98,    64,  -186,     5,  -186,  -186,  -186,  -119,
    -186,  -186,   -80,  -186,  -186,  -146,  -186,  -186,  -186,  -186,
    -185,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,   -40,   125,  -186,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,  -186,
    -186,   -84,  -186,  -186,  -186,   -58,  -186,   -57,  -186,  -186,
    -186,  -186,    -8
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -158
static const yytype_int16 yytable[] =
{
      17,   122,   163,   182,    25,   129,   119,   120,   183,   184,
      75,    20,   153,   154,   155,     1,   156,   157,   187,   188,
      33,    55,   110,   111,    40,     6,   112,    45,     5,    49,
       7,    93,    54,   239,   240,    70,    72,    12,    13,    17,
     103,    14,    45,    21,    79,    22,    56,    23,    24,    18,
      57,    58,    59,    26,    28,    31,    34,   179,   180,    35,
      37,    60,    61,    45,    42,    38,    49,   100,    46,    50,
     237,   238,    45,    51,   129,   108,    52,    71,    74,    76,
      80,    85,    86,   -75,    70,    87,    88,   125,    97,   206,
      92,    91,   215,    95,   209,   130,   102,   140,   141,   136,
     142,   143,   144,   145,   146,   147,   150,   104,   105,   109,
     106,   220,   121,   165,   221,   124,   126,   223,   127,   133,
     171,   226,   134,    17,   176,   162,   172,   139,   202,   166,
     194,   174,   232,   191,   169,   197,   201,   200,   207,   203,
    -157,   222,   224,   186,   190,   244,   231,   230,   163,   233,
     245,   193,   196,   199,   234,   241,   246,   248,   264,   258,
     205,   261,   262,   268,   130,   265,   279,   276,    10,   108,
     213,    73,   173,   273,   228,   280,   274,   123,   266,   257,
     208,   158,   210,   271,   251,     0,   252,     0,     0,     0,
       0,     0,   282,     0,     0,    79,     0,     0,     0,    96,
       0,     0,     0,     0,     0,     0,     0,   236,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   196,   199,   254,     0,   256,     0,
       0,   260,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   165,
       0,   100,   260,     0,   278,     0,   254,     0,   256
};

static const yytype_int16 yycheck[] =
{
       8,    90,   121,   149,    14,   103,    86,    87,     9,    10,
      50,     7,     3,     4,     5,    52,     7,     8,    11,    12,
      28,     7,     9,    10,    32,     0,    13,    35,    26,    37,
      53,    71,    42,   218,   219,    43,    46,     7,     7,    47,
      80,    50,    50,    39,    52,    41,    32,    43,    44,    27,
      36,    37,    38,    33,    15,    54,     7,   137,   138,    15,
      15,    47,    48,    71,    35,    55,    74,    75,    35,    15,
     216,   217,    80,    16,   172,    83,    13,    19,    19,    19,
      15,    13,    13,    22,    92,    13,     7,    97,    50,   169,
      19,    16,   181,    16,   174,   103,    14,    23,    24,   107,
      26,    27,    28,    29,    30,    31,   114,    19,     7,    22,
      21,   191,    13,   121,   194,     7,    16,   197,     7,     7,
     128,   201,    13,   131,   132,     7,    19,    14,     7,    49,
      20,    17,   212,    17,    51,    20,    13,    20,    16,    20,
      14,    14,    14,   151,   152,   225,    14,    18,   267,    14,
      14,   159,   160,   161,    34,    18,    13,    19,    14,    20,
     168,   250,    20,     7,   172,    19,    14,    20,     4,   177,
     178,    47,   131,   269,   203,   276,   270,    92,   258,   247,
     172,   117,   177,   267,   242,    -1,   243,    -1,    -1,    -1,
      -1,    -1,   281,    -1,    -1,   203,    -1,    -1,    -1,    74,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   215,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   242,   243,   246,    -1,   246,    -1,
      -1,   249,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   267,
      -1,   269,   270,    -1,   272,    -1,   276,    -1,   276
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    52,    57,    63,    64,    26,     0,    53,    58,    59,
      64,    65,     7,     7,    50,    66,    68,   158,    27,    60,
       7,    39,    41,    43,    44,    76,    33,   156,    15,    69,
     157,    54,    61,   158,     7,    15,    92,    15,    55,    62,
     158,    70,    35,   127,   129,   158,    35,   128,   133,   158,
      15,    16,    13,    77,    76,     7,    32,    36,    37,    38,
      47,    48,    93,    98,    99,   105,   135,   139,   148,   155,
     158,    19,    76,    66,    19,   127,    19,    76,    79,   158,
      15,    94,   130,   100,   106,    13,    13,    13,     7,   140,
     146,    16,    19,   127,   134,    16,   128,    50,    67,    72,
     158,    80,    14,   127,    19,     7,    21,   101,   158,    22,
       9,    10,    13,   108,   111,   116,   121,   124,   158,   108,
     108,    13,    92,    93,     7,    76,    16,     7,    95,    98,
     158,    71,   131,     7,    13,   103,   158,   107,   122,    14,
      23,    24,    26,    27,    28,    29,    30,    31,   109,   110,
     158,   112,   117,     3,     4,     5,     7,     8,    99,   126,
     149,   150,     7,   105,   147,   158,    49,    73,    81,    51,
      96,   158,    19,    68,    17,   132,   158,   102,   104,   108,
     108,   136,   111,     9,    10,   113,   158,    11,    12,   118,
     158,    17,   125,   158,    20,   151,   158,    20,   153,   158,
      20,    13,     7,    20,    82,   158,   108,    16,    95,   108,
     101,    87,    88,   158,   123,    92,   114,   115,   119,   120,
     108,   108,    14,   108,    14,   141,   108,    74,    79,    97,
      18,    14,   108,    14,    34,   137,   158,   111,   111,   116,
     116,    18,   152,   154,   108,    14,    13,    78,    19,    89,
     138,   151,   153,   142,    76,    83,   158,    94,    20,    90,
     158,    92,    20,    84,    14,    19,   108,   143,     7,    75,
      91,   147,    85,    72,    90,   144,    20,    86,   158,    14,
      83,   145,    92
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:

/* Line 1455 of yacc.c  */
#line 225 "parser.y"
    { 
						objetoNombre = yytext; 
						objeto = true;
						dirProcedimientos.crearObjeto(objetoNombre); 

					;}
    break;

  case 5:

/* Line 1455 of yacc.c  */
#line 230 "parser.y"
    {
						//resetOffsetIndexes(local);
						objeto = false;
						dirProcedimientos.terminaBloque();
					;}
    break;

  case 16:

/* Line 1455 of yacc.c  */
#line 254 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 17:

/* Line 1455 of yacc.c  */
#line 254 "parser.y"
    {
						funcionNombre = (yyvsp[(4) - (4)].sval);
						accion_1_definicion_proc(yyTipo, (yyvsp[(4) - (4)].sval));
					 	funcion = true; 
					 	global = false;
					;}
    break;

  case 18:

/* Line 1455 of yacc.c  */
#line 259 "parser.y"
    {
						
						
					 	global = true;
						funcion = false; 
					  	dirProcedimientos.terminaBloque();
					;}
    break;

  case 21:

/* Line 1455 of yacc.c  */
#line 268 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 22:

/* Line 1455 of yacc.c  */
#line 268 "parser.y"
    {
						funcionNombre = (yyvsp[(4) - (4)].sval);
						//dirProcedimientos.crearMetodo(yyTipo, $4);
						accion_1_definicion_proc(yyTipo, (yyvsp[(4) - (4)].sval));
						global = false; 

					;}
    break;

  case 23:

/* Line 1455 of yacc.c  */
#line 274 "parser.y"
    {
					  // resetOffsetIndexes(local);
					  global = true; 
					  dirProcedimientos.terminaBloque();
					;}
    break;

  case 33:

/* Line 1455 of yacc.c  */
#line 292 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 292 "parser.y"
    {
						int direccion_virtual = getSiguienteDireccion(getIndexTipoVariable(yyTipo), 0, global, temporal, objeto, funcion);

						accion_2_definicion_proc(yyTipo, (yyvsp[(3) - (3)].sval), direccion_virtual);
					;}
    break;

  case 39:

/* Line 1455 of yacc.c  */
#line 301 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 40:

/* Line 1455 of yacc.c  */
#line 301 "parser.y"
    {
						int direccion_virtual = getSiguienteDireccion(getIndexTipoVariable(yyTipo), 0, global, temporal, objeto, funcion);
						accion_2_definicion_proc(yyTipo, (yyvsp[(3) - (3)].sval), direccion_virtual);
						// dirProcedimientos.agregaParametro(yyTipo, $3, direccion_virtual);

					;}
    break;

  case 45:

/* Line 1455 of yacc.c  */
#line 312 "parser.y"
    {

					  int tipoObjeto = -1;
					  // Si es un metodo de un objeto, entocnes consigo el tipo del objeto que invoca
					  if ( metodo ) { 
					   	tipoObjeto = dirProcedimientos.checaTipo(objetoNombre);
					  }

					   if ( !dirProcedimientos.comienzaArgumentos(tipoObjeto, objetoNombre)) {

					   		cout << "Error:" << endl;
					   		exit(-1);
					   }

					;}
    break;

  case 46:

/* Line 1455 of yacc.c  */
#line 326 "parser.y"
    { 
					  accion_3_llamada_proc();
					;}
    break;

  case 49:

/* Line 1455 of yacc.c  */
#line 331 "parser.y"
    {
					  accion_3_llamada_proc();
					;}
    break;

  case 51:

/* Line 1455 of yacc.c  */
#line 334 "parser.y"
    {
						dirProcedimientos.terminaArgumentos();

					;}
    break;

  case 55:

/* Line 1455 of yacc.c  */
#line 346 "parser.y"
    {		


						Cuadruplo cuadruploTemp = Cuadruplo("retorno", "", "" , "");
						cuadruplos.push_back( cuadruploTemp );	
					;}
    break;

  case 58:

/* Line 1455 of yacc.c  */
#line 354 "parser.y"
    {
						accion_7_definicion_proc();
					;}
    break;

  case 67:

/* Line 1455 of yacc.c  */
#line 368 "parser.y"
    {
					 	
					// 1. Meter a pilaO (direccion de variable) y meter a PTipos el tipo de variable
					// si es 4, entonces es un identificador

					   metodo = false;
					   objetoNombre = (yyvsp[(1) - (1)].sval);
					   metodoNombre = (yyvsp[(1) - (1)].sval);
					   int variableIndex = dirProcedimientos.buscaVariable(objetoNombre);

					   if (variableIndex == -1 ) { 
							cerr << "ERROR: Variable not found:  \"" << objetoNombre;
							cerr << "\" on line " << line_num << endl;
							exit(-1);
						}



					;}
    break;

  case 68:

/* Line 1455 of yacc.c  */
#line 386 "parser.y"
    {
						accion_6_llamada_proc(objetoNombre);
					;}
    break;

  case 69:

/* Line 1455 of yacc.c  */
#line 389 "parser.y"
    {
					  metodoNombre = (yyvsp[(2) - (2)].sval);
					  metodo = true;
						// aqui es un metodo
						accion_1_llamada_proc_predicado(objetoNombre, metodoNombre);
					;}
    break;

  case 72:

/* Line 1455 of yacc.c  */
#line 396 "parser.y"
    {
						// mete fondo falso
						accion_6_expresiones("(");
						//cout << "Metodo nombre" << metodoNombre << endl;
						// Si es una funcion, no tenia .getX(), solo era getX()
						if ( metodo == false) {
							// aqui es una funcion o una variable
							accion_1_llamada_proc_no_predicado(objetoNombre, metodoNombre);
						}
					
						
						accion_2_llamada_proc();

					;}
    break;

  case 73:

/* Line 1455 of yacc.c  */
#line 409 "parser.y"
    {
						accion_7_expresiones();
						accion_5_llamada_proc();

					;}
    break;

  case 74:

/* Line 1455 of yacc.c  */
#line 414 "parser.y"
    {
						if ( metodo ) {
							//cout << "Metodo: " << metodoNombre << endl;
							// es una variable de objeto, ejemplo x.valorX
							accion_1_expresiones(metodoNombre, 4);
						}
						else {
							//cout << "Variable: " << objetoNombre << endl;



							accion_1_expresiones(objetoNombre, 4);

						}

					;}
    break;

  case 75:

/* Line 1455 of yacc.c  */
#line 431 "parser.y"
    {
										int direccionVariable = dirProcedimientos.buscaDireccion((yyvsp[(1) - (1)].sval));
										int tipoVariable = dirProcedimientos.checaTipo((yyvsp[(1) - (1)].sval));
										accion_1_assignacion(direccionVariable, tipoVariable);
										int variableIndex = dirProcedimientos.buscaVariable((yyvsp[(1) - (1)].sval));
										if (variableIndex == -1 ) { 
											cerr << "ERROR: at symbol \"" << yytext;
											cerr << "\" on line " << line_num << endl;
											exit(-1);
										}
										int esVariable = dirProcedimientos.esVariable(variableIndex);
										if ( !esVariable ) { 
											cerr << "ERROR: en el simbolo  \"" << yytext;
											cerr << "\"  no se puede asignar contenido a un metodo, en linea " << line_num << endl;
											exit(-1);
										}
										
									;}
    break;

  case 76:

/* Line 1455 of yacc.c  */
#line 449 "parser.y"
    {
								accion_2_assignacion("=");
						;}
    break;

  case 77:

/* Line 1455 of yacc.c  */
#line 452 "parser.y"
    {

								accion_3_assignacion();
								
						;}
    break;

  case 79:

/* Line 1455 of yacc.c  */
#line 461 "parser.y"
    { accion_9_expresiones(); ;}
    break;

  case 81:

/* Line 1455 of yacc.c  */
#line 464 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 82:

/* Line 1455 of yacc.c  */
#line 465 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 83:

/* Line 1455 of yacc.c  */
#line 466 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 84:

/* Line 1455 of yacc.c  */
#line 467 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 85:

/* Line 1455 of yacc.c  */
#line 468 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 86:

/* Line 1455 of yacc.c  */
#line 469 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 87:

/* Line 1455 of yacc.c  */
#line 470 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 88:

/* Line 1455 of yacc.c  */
#line 471 "parser.y"
    { accion_8_expresiones(yytext); ;}
    break;

  case 89:

/* Line 1455 of yacc.c  */
#line 473 "parser.y"
    { accion_4_expresiones(); ;}
    break;

  case 91:

/* Line 1455 of yacc.c  */
#line 474 "parser.y"
    {
								accion_2_expresiones(yytext);
								
						   ;}
    break;

  case 93:

/* Line 1455 of yacc.c  */
#line 478 "parser.y"
    {
								accion_2_expresiones(yytext);
						   ;}
    break;

  case 96:

/* Line 1455 of yacc.c  */
#line 483 "parser.y"
    { accion_5_expresiones(); ;}
    break;

  case 98:

/* Line 1455 of yacc.c  */
#line 484 "parser.y"
    {
								accion_3_expresiones(yytext);
						   ;}
    break;

  case 100:

/* Line 1455 of yacc.c  */
#line 487 "parser.y"
    {
								accion_3_expresiones(yytext);
						   ;}
    break;

  case 103:

/* Line 1455 of yacc.c  */
#line 492 "parser.y"
    { accion_6_expresiones("("); ;}
    break;

  case 104:

/* Line 1455 of yacc.c  */
#line 492 "parser.y"
    { accion_7_expresiones(); ;}
    break;

  case 112:

/* Line 1455 of yacc.c  */
#line 502 "parser.y"
    { 

										
									 ;}
    break;

  case 113:

/* Line 1455 of yacc.c  */
#line 506 "parser.y"
    { 
										// 1. Meter a pilaO (direccion de variable) y meter a PTipos el tipo de variable
										accion_1_expresiones(yytext, 1);
								;}
    break;

  case 114:

/* Line 1455 of yacc.c  */
#line 510 "parser.y"
    { 
										// 1. Meter a pilaO (direccion de variable) y meter a PTipos el tipo de variable
										accion_1_expresiones(yytext, 0);
									;}
    break;

  case 115:

/* Line 1455 of yacc.c  */
#line 514 "parser.y"
    { 
										// 1. Meter a pilaO (direccion de variable) y meter a PTipos el tipo de variable
										accion_1_expresiones(yytext, 3);
									;}
    break;

  case 116:

/* Line 1455 of yacc.c  */
#line 518 "parser.y"
    { 
										// 1. Meter a pilaO (direccion de variable) y meter a PTipos el tipo de variable
										accion_1_expresiones(yytext, 2);

									;}
    break;

  case 121:

/* Line 1455 of yacc.c  */
#line 535 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 122:

/* Line 1455 of yacc.c  */
#line 535 "parser.y"
    {  
									//TODO Hace funcion que me regrese la direccion. 
									
									int direccion;
									
									direccion = getSiguienteDireccion(getIndexTipoVariable(yyTipo), 0,  global, temporal, objeto, funcion);

									
									//cout << "Crear variable Tipo: " << yyTipo << " Nombre: " << $4 << " Direccion: " <<   direccion << " global: " << global   << endl;
									//cout << "Bloque actual en variable: " << dirProcedimientos.bloqueAct  << endl;
									if ( !dirProcedimientos.crearVariable(yyTipo, (yyvsp[(4) - (4)].sval), 1, direccion )) {
										exit (-1);
									};

								   ;}
    break;

  case 126:

/* Line 1455 of yacc.c  */
#line 554 "parser.y"
    { yyTipo = yytext ;}
    break;

  case 127:

/* Line 1455 of yacc.c  */
#line 554 "parser.y"
    {  
									//TODO Hace funcion que me regrese la direccion. 
									

									dirProcedimientos.crearVariable(yyTipo, (yyvsp[(4) - (4)].sval), 0, getSiguienteDireccion(getIndexTipoVariable(yyTipo), 0, global, temporal, objeto, funcion));
								   ;}
    break;

  case 128:

/* Line 1455 of yacc.c  */
#line 564 "parser.y"
    {
						accion_1_condicion_fallo();
					;}
    break;

  case 130:

/* Line 1455 of yacc.c  */
#line 567 "parser.y"
    {
						accion_2_condicion_fallo();
					;}
    break;

  case 131:

/* Line 1455 of yacc.c  */
#line 569 "parser.y"
    {
						accion_3_condicion_fallo();
					;}
    break;

  case 133:

/* Line 1455 of yacc.c  */
#line 575 "parser.y"
    {
							
					;}
    break;

  case 134:

/* Line 1455 of yacc.c  */
#line 577 "parser.y"
    {
						accion_1_ciclo();
					;}
    break;

  case 135:

/* Line 1455 of yacc.c  */
#line 579 "parser.y"
    {
						accion_2_ciclo();
					;}
    break;

  case 136:

/* Line 1455 of yacc.c  */
#line 581 "parser.y"
    {
						accion_3_ciclo();
					;}
    break;

  case 137:

/* Line 1455 of yacc.c  */
#line 583 "parser.y"
    {
						accion_4_ciclo();
					;}
    break;

  case 138:

/* Line 1455 of yacc.c  */
#line 585 "parser.y"
    {
						accion_5_ciclo();
					;}
    break;

  case 139:

/* Line 1455 of yacc.c  */
#line 587 "parser.y"
    {
						accion_6_ciclo();
					;}
    break;

  case 140:

/* Line 1455 of yacc.c  */
#line 590 "parser.y"
    {
						accion_1_haz_mientras();
					;}
    break;

  case 141:

/* Line 1455 of yacc.c  */
#line 592 "parser.y"
    {
						accion_2_haz_mientras();
					;}
    break;

  case 144:

/* Line 1455 of yacc.c  */
#line 598 "parser.y"
    { accion_1_print(); ;}
    break;

  case 146:

/* Line 1455 of yacc.c  */
#line 599 "parser.y"
    { accion_1_print(); ;}
    break;

  case 147:

/* Line 1455 of yacc.c  */
#line 599 "parser.y"
    { accion_2_print(); ;}
    break;

  case 148:

/* Line 1455 of yacc.c  */
#line 601 "parser.y"
    { accion_1_print(); ;}
    break;

  case 151:

/* Line 1455 of yacc.c  */
#line 604 "parser.y"
    { accion_1_print(); ;}
    break;

  case 154:

/* Line 1455 of yacc.c  */
#line 608 "parser.y"
    { accion_1_read(yytext); ;}
    break;

  case 155:

/* Line 1455 of yacc.c  */
#line 610 "parser.y"
    {
						int inicio = pilaSaltos.top();
						pilaSaltos.pop();
						rellenar(inicio, cuadruplos.size()  );
					;}
    break;

  case 156:

/* Line 1455 of yacc.c  */
#line 614 "parser.y"
    { printCuadruplos(); ;}
    break;



/* Line 1455 of yacc.c  */
#line 2516 "parser.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 621 "parser.y"


int main(int argc, char **argv) {
	// open a file handle to a particular file:
	// FILE *myfile = fopen("a.snazzle.file", "r");

	yyin = fopen(argv[1], "r");
	
	Cuadruplo cuadruploTemp = Cuadruplo("goto", "", "", to_string(-1));
	cuadruplos.push_back( cuadruploTemp );	

	pilaSaltos.push(cuadruplos.size() -1 );

	
	yyparse();
	
    dirProcedimientos.inicializaMemoria();
    
	solve();

	cout << "Success reading file" << endl; 

	return 0;

	

}

void yyerror(const char *s) {


	extern int yylineno;	// defined and maintained in lex.c
 	extern char *yytext;	// defined and maintained in lex.c
 		 
    cerr << "ERROR: " << s << " at symbol \"" << yytext;
	cerr << "\" on line " << line_num << endl;
	exit(-1);
}

void accion_1_expresiones(string yytext, int tipo){
	
	// Si no era una variable registrada y es constante
	if ( tipo != 4 ) {
		// crea variable constante en el scope
		constante constante; 
		global = false;
		switch (tipo) {
			case 0: // bandera

				constante.direccion = getSiguienteDireccion(tipo, 1, global, temporal, objeto, funcion);
				constante.tipo = 0;
				constante.valor = yytext;
				constantesBandera.push_back(constante);		

			break;
			case 1: // entero
				constante.direccion = getSiguienteDireccion(tipo, 1, global, temporal, objeto, funcion);
				constante.tipo = 1;
				constante.valor = yytext;
				constantesEnteras.push_back(constante);			
			break;
			case 2: // decimal
				constante.direccion = getSiguienteDireccion(tipo, 1, global, temporal, objeto, funcion);
				constante.tipo = 2;
				constante.valor = yytext;		
				constantesDecimales.push_back(constante);			

			break;
			case 3: // texto
				constante.direccion = getSiguienteDireccion(tipo, 1, global, temporal, objeto, funcion);
				constante.tipo = 3;
				constante.valor = yytext;
				constantesTexto.push_back(constante);

			break;
		}
		global = true;
		
		pilaOperandos.push(constante.direccion);
		pilaTipos.push(constante.tipo);
		
		
		
	}
	else {

		// la variable ya estaba registrada

		int direccionVariable = dirProcedimientos.buscaDireccion(yytext);
		
		if (direccionVariable != -1 ) {

			
			int tipoVariable = dirProcedimientos.checaTipo(yytext);

			int estructuraVariable = dirProcedimientos.checaEstructura(yytext);


			//0 bandera, 1 entero, 2 decimal, 3 texto
			// estructura 0 variable, 1 funcion
			if (tipoVariable < 4 && ( estructuraVariable == 0 )  ) {
			


				pilaOperandos.push(direccionVariable);
				pilaTipos.push(tipoVariable);

			}
			else  {
				cout << "No se permiten operaciones entre objetos";
				exit(0);
			}
		}
		else {
			cout << "Linea: " << line_num << endl;
			exit(0);
		}
	}
	

}

void accion_2_expresiones(string operador){
	
	pilaOperadores.push(operador);
	
}

void accion_3_expresiones(string operador){
	
	pilaOperadores.push(operador);
	
}

void accion_4_expresiones() {
	// Si top de pOperadores = + or -
	
	if ( pilaOperadores.size() != 0 ) {

		if ( pilaOperadores.top() == "+" || pilaOperadores.top() == "-") {
			
			int tipoDer = -1, tipoIzq = -1;
			int tipoResultado = -1, tipoOperador;
			tipoDer = pilaTipos.top();
			pilaTipos.pop();

			tipoIzq = pilaTipos.top();
			pilaTipos.pop();

			//Checa si son permitidas las operaciones
			string operador = pilaOperadores.top();
			pilaOperadores.pop();

			tipoOperador  = getIndexOperador(operador);



			tipoResultado = cuboSemantico[tipoIzq][tipoDer][tipoOperador];

			if (tipoResultado != -1 ) {

				temporal = true;
				int der, izq;

				der = pilaOperandos.top();
				pilaOperandos.pop();

				izq = pilaOperandos.top();
				pilaOperandos.pop();

				// Aumenta los temporales en 1
				int resultado = getSiguienteDireccion(tipoResultado,0,global, temporal, objeto,  funcion);
				Cuadruplo cuadruploTemp = Cuadruplo(operador, to_string(izq), to_string(der), to_string(resultado));
				cuadruplos.push_back( cuadruploTemp );

				pilaOperandos.push(resultado);

				pilaTipos.push(tipoResultado);
				temporal = false;				

			}	
			else {
				cerr << "Tipos incompatibles en la linea: " << line_num <<  endl;
				exit(-1);
			}	

		}
	}
	
}


void accion_5_expresiones() {
	// Si top de pOperadores = * or /
	
	if ( pilaOperadores.size() != 0 ) {
		if ( pilaOperadores.top() == "/" || pilaOperadores.top() == "*") {
			
			int tipoDer = -1, tipoIzq = -1;
			int tipoResultado = -1, tipoOperador;
			tipoDer = pilaTipos.top();
			pilaTipos.pop();

			tipoIzq = pilaTipos.top();
			pilaTipos.pop();
			
			//Checa si son permitidas las operaciones
			string operador = pilaOperadores.top();
			pilaOperadores.pop();
			
			tipoOperador  = getIndexOperador(operador);
			
			tipoResultado = cuboSemantico[tipoIzq][tipoDer][tipoOperador];
			

			if (tipoResultado != -1 ) {

				temporal = true;
				int der, izq;

				der = pilaOperandos.top();
				pilaOperandos.pop();

				izq = pilaOperandos.top();
				pilaOperandos.pop();
				//cout << "getsiguietneDireccion " << tipoResultado << " const: " << 0 << " glob: " << global << " temp: " << temporal << " objeto: " << objeto << " funcion: " << funcion << endl; 
				// Aumenta los temporales en 1
				int resultado = getSiguienteDireccion(tipoResultado, 0, global, temporal, objeto, funcion);
				
				Cuadruplo cuadruploTemp = Cuadruplo(operador, to_string(izq), to_string(der), to_string(resultado));
				cuadruplos.push_back( cuadruploTemp );

				pilaOperandos.push(resultado);

				pilaTipos.push(tipoResultado);
				
				temporal = false;

			}	
			else {
				cerr << "Tipos incompatibles en la linea " << line_num << endl
;				exit(-1);
			}	

		}
	}
	
}

void accion_6_expresiones(string fondoFalso){
	
	pilaOperadores.push(fondoFalso);
	
}
void accion_7_expresiones(){
	
	pilaOperadores.pop();
	
}
void accion_8_expresiones(string operador){
	
	
	pilaOperadores.push(operador);
	
}

void accion_9_expresiones(){
	
	
	// Si top de pOperadores = > or < 
	if ( pilaOperadores.size() != 0 ) {
		if ( pilaOperadores.top() == ">" || pilaOperadores.top() == "<" || pilaOperadores.top() == "==" 
			|| pilaOperadores.top() == "!=" || pilaOperadores.top() == ">=" || pilaOperadores.top() == "<="
			|| pilaOperadores.top() == "||" || pilaOperadores.top() == "&&") {

			int tipoDer = -1, tipoIzq = -1;
			int tipoResultado = -1, tipoOperador;
			tipoDer = pilaTipos.top();
			pilaTipos.pop();

			tipoIzq = pilaTipos.top();
			pilaTipos.pop();

			//Checa si son permitidas las operaciones
			string operador = pilaOperadores.top();
			pilaOperadores.pop();

			tipoOperador  = getIndexOperador(operador);
			tipoResultado = cuboSemantico[tipoIzq][tipoDer][tipoOperador];

			if (tipoResultado != -1 ) {


				temporal = true;
				int der, izq;
				der = pilaOperandos.top();
				pilaOperandos.pop();

				izq = pilaOperandos.top();
				pilaOperandos.pop();

				// Aumenta los temporales en 1
				int resultado = getSiguienteDireccion(tipoResultado, 0, global, temporal, objeto, funcion);
				
				Cuadruplo cuadruploTemp = Cuadruplo(operador, to_string(izq), to_string(der), to_string(resultado));
				cuadruplos.push_back( cuadruploTemp );

				pilaOperandos.push(resultado);

				pilaTipos.push(tipoResultado);
				temporal = false;

			}	
			else {
				cerr << "Tipos incompatibles en la linea: " << line_num << endl;
				exit(-1);
			}	

		}
	}
	
}


void accion_1_assignacion(int dirOperando, int tipoVariable){
	//Meter id en PilaO
	

	pilaTipos.push(tipoVariable);
	pilaOperandos.push(dirOperando);

	
}

void accion_2_assignacion(string operador){
	//Meter = en pilaOperadores
	
	pilaOperadores.push(operador);
	
}
void accion_3_assignacion( ){
	// sacar der de pilaO
	// sacar izq de pilaO
	// asigna = pOperadores.pop()
	// genera
	//		asigna, der, , izq
	
	int der = pilaOperandos.top();
	pilaOperandos.pop();
	int tipoDer = pilaTipos.top();
	pilaTipos.pop();
	
	//cout << "Der: " << der <<  " Tipo: " << tipoDer << endl;

	int izq = pilaOperandos.top();
	pilaOperandos.pop();
	int tipoIzq = pilaTipos.top();
	pilaTipos.pop();
	
	//cout << "Izq: " << izq <<  " Tipo: " << tipoIzq << endl;

	string asigna = pilaOperadores.top();
	pilaOperadores.pop();

	// Si son vacios, entocnes error..
	if ( tipoDer == 4 || tipoIzq == 4 ){ 
		cerr << "SEMANTIC ERROR, WRONG TYPE OF VARIABLE on line " << line_num << endl;
		exit(-1);
	}

	int tipoOperador  = getIndexOperador(asigna);
	int tipoResultado = cuboSemantico[tipoIzq][tipoDer][tipoOperador];


	if ( tipoResultado != -1 ) {

		Cuadruplo cuadruploTemp = Cuadruplo(asigna, to_string(der), "", to_string(izq));
		cuadruplos.push_back( cuadruploTemp );
	} else {
				cerr << "Tipos incompatibles en linea: " << line_num <<   endl;
				exit(-1);
	}

}

void accion_1_condicion_fallo() {
	// aux = pop PTipos
	// si aux diferente de boleano, entonces error semantico
	// sino 
	//		sacar resultado de pilaO
	//		Generar gotoF, resultado, , ___
	//		PUSH PSaltos(cont-1)

	
	int aux = pilaTipos.top();
	pilaTipos.pop();

	if ( aux != 0 ) {
		cerr << "SEMANTIC ERROR: on line " << line_num << endl;
		exit(-1);
	}

	else {
		int resultado = pilaOperandos.top();
		pilaOperandos.pop();
	
		Cuadruplo cuadruploTemp = Cuadruplo("gotoF", to_string(resultado), "" , to_string(-1));
		cuadruplos.push_back( cuadruploTemp );
		
		pilaSaltos.push( cuadruplos.size() -1 );

	}
	
}

void accion_2_condicion_fallo(){
	// Genrar goto ____
	// Sacar falso de PSaltos
	//rellenar(falso,cont)
	//PUSH PSaltos (cont-1)
	
	Cuadruplo cuadruploTemp = Cuadruplo("goto", "", "", to_string(-1));
	cuadruplos.push_back( cuadruploTemp );	

	int falso = pilaSaltos.top();
	pilaSaltos.pop();
	
	rellenar(falso, cuadruplos.size()  );
	
	pilaSaltos.push( cuadruplos.size() -1 );

	
}

void accion_3_condicion_fallo() {
	//Sacar fin de PSaltos
	//rellenar (fin, cont);
	
	int fin = pilaSaltos.top();
	pilaSaltos.pop();

	rellenar(fin, cuadruplos.size()  );

}

void accion_1_print() {
	
	int res = pilaOperandos.top();
	pilaOperandos.pop();

	Cuadruplo cuadruploTemp = Cuadruplo("muestra", "", "" , to_string(res));
	cuadruplos.push_back( cuadruploTemp );	

	
}

void accion_2_print() {
	
	

	Cuadruplo cuadruploTemp = Cuadruplo("saltolinea", "", "" , "");
	cuadruplos.push_back( cuadruploTemp );	

	
}


void accion_1_read(string nombre) { 


	int variableIndex = dirProcedimientos.buscaVariable(nombre);
	bool esVariable = dirProcedimientos.esVariable(variableIndex);



   if (variableIndex == -1 ) { 
		cerr << "ERROR: Variable not found:  \"" << nombre;
		cerr << "\" on line " << line_num << endl;
		exit(-1);
	}

   if ( !esVariable ) { 
		cerr << "ERROR: No se pueden leer metodos:  \"" << nombre;
		cerr << "\" on line " << line_num << endl;
		exit(-1);
	}

	int direccionVariable = dirProcedimientos.buscaDireccion(nombre);
	Cuadruplo cuadruploTemp = Cuadruplo("lee", "", "" , to_string(direccionVariable) );
	cuadruplos.push_back( cuadruploTemp );	

	

}
void accion_1_ciclo() {
	// meter cont en PSaltos

	pilaSaltos.push( cuadruplos.size() );

	
}

void accion_2_ciclo() {
	// sacar aux de ptipos
	/// si aux diferente booleano, generar error semantico
	// sino
	//		sacar resultado de pilaO
	//		generar gotofalso, , ,resultado
	//		PUSH PSaltos (cont-1)
	
	int aux = pilaTipos.top();
	pilaTipos.pop();

	if ( aux != 0 ) {
		cerr << "SEMANTIC ERROR: on line " << line_num << endl;
		exit(-1);
	} else {
		int resultado = pilaOperandos.top();
		pilaOperandos.pop();
	
		Cuadruplo cuadruploTemp = Cuadruplo("gotoF", to_string(resultado), "" , to_string(-1));
		cuadruplos.push_back( cuadruploTemp );
		
		pilaSaltos.push( cuadruplos.size() -1 );

		cuadruploTemp = Cuadruplo("goto", "", "" , to_string(-1)); //bloque
		cuadruplos.push_back( cuadruploTemp );
		
		pilaSaltos.push( cuadruplos.size() -1 );

	}

	
}

void accion_3_ciclo() {
	// generar ppushPila salto del asigna
	

	pilaSaltos.push( cuadruplos.size()  ); 

	
}

void accion_4_ciclo() {
	// Generar accion de goto retorno despues de la asignacion del ciclo

	int asigna = pilaSaltos.top();
	pilaSaltos.pop();

	int gotoBloque = pilaSaltos.top();
	pilaSaltos.pop();

	int gotoFalso = pilaSaltos.top();
	pilaSaltos.pop();

	int retorno = pilaSaltos.top();
	pilaSaltos.pop();



	Cuadruplo cuadruploTemp = Cuadruplo("goto", "", "", to_string(retorno));
	cuadruplos.push_back( cuadruploTemp );

	pilaSaltos.push( gotoFalso );
	pilaSaltos.push( gotoBloque );
	pilaSaltos.push( asigna );
	

}
void accion_5_ciclo() {
	// Genera accion de relleno de bloque hacia primera instruccion de estatutos de bloque

	int asigna = pilaSaltos.top();
	pilaSaltos.pop();

	int bloque = pilaSaltos.top();
	pilaSaltos.pop();
	
	rellenar(bloque, cuadruplos.size()  );

	pilaSaltos.push( asigna );

}
void accion_6_ciclo() {
	// Genera accion de relleno de asigna

	int asigna = pilaSaltos.top();
	pilaSaltos.pop();
	
	Cuadruplo cuadruploTemp = Cuadruplo("goto", "", "", to_string(asigna));
	cuadruplos.push_back( cuadruploTemp );

	int falso = pilaSaltos.top();
	pilaSaltos.pop();
	
	rellenar(falso, cuadruplos.size()  );

}





void accion_1_haz_mientras() {
	// meter cont en PSaltos
	

	if ( debug ) {}

	pilaSaltos.push( cuadruplos.size() );

	
}

void accion_2_haz_mientras() {
	// sacar resultado de pSaltos, sacar retorno de pSaltos
	// generar gotofalso resultado retorno
	

	int resultado = pilaOperandos.top();
	pilaOperandos.pop();

	pilaTipos.pop();

	int retorno = pilaSaltos.top();
	pilaSaltos.pop();
	

	Cuadruplo cuadruploTemp = Cuadruplo("gotoT", to_string(resultado), "", to_string(retorno));
	cuadruplos.push_back( cuadruploTemp );


}


void accion_1_definicion_proc(string tipo, string nombre) {
	// Dar de alta el nombre del procedimiento en el Dir de Procs
	// Verificar la semantica
	

	
	int direccion = getSiguienteDireccion(getIndexTipoVariable(yyTipo), 0, global, temporal, objeto, funcion);
	//cout << "Crear metodo " << nombre << " Direccion: " << direccion << " Tipo: " << yyTipo <<  endl;
	if ( !dirProcedimientos.crearMetodo(tipo, nombre,direccion, cuadruplos.size() ) ) {
		exit(-1);
	};

	//cout << "Crear variable Tipo: " << yyTipo << " Nombre: " << nombre << " Direccion: " <<   direccion   << endl;

	
}

void accion_2_definicion_proc(string tipo, string nombre, int direccion) {
	// Ligar cada parametro a la tabla de parametros del dir de procs
	//cout << "Crear parametro " << nombre << " Direccion: " << direccion << endl;
	dirProcedimientos.agregaParametro(tipo, nombre, direccion);
}


void accion_7_definicion_proc() {
	// Liberar la tabla de variables locales del procedimiento
	// Generar una accion de RETORNO
	

	int resultado = pilaOperandos.top();
	pilaOperandos.pop();
	int tipoOperando = pilaTipos.top();
	pilaTipos.pop();
	

	int direccionMetodo = dirProcedimientos.buscaDireccion(funcionNombre);
	int tipoFuncion = dirProcedimientos.checaTipo(funcionNombre);
	int tipoOperador  = getIndexOperador("=");

	int tipoResultado = cuboSemantico[tipoOperando][tipoFuncion][tipoOperador];
	
	if ( tipoResultado != -1 ) {

		Cuadruplo cuadruploTemp = Cuadruplo("=", to_string(resultado), "" , to_string(direccionMetodo));
		cuadruplos.push_back( cuadruploTemp );	

	} else {
		cerr << "Tipos incompatibles en linea: " << line_num <<   endl;
		exit(-1);
	}
	
}


void accion_1_llamada_proc_predicado(string objetoNombre, string metodoNombre) {
	// Verificar que el procedimiento exista como tal en el Dir. de procs
		
	/*
	bool existePredicado = dirProcedimientos.checaPredicado(objetoNombre);
	int estructuraVariable = dirProcedimientos.checaEstructura(objetoNombre);
		
	// 1 = funciones, 0 = variable, 2 = objeto
	cout << "NOmbre objeto: " << objetoNombre << " metodoNombre: "<<  metodoNombre<<  " existePredicado: " << existePredicado << " estructuraVariable: " << estructuraVariable << endl;
	if (existePredicado == false && estructuraVariable != 1) { 
		cerr << "ERROR: Method not found:  \"" << metodoNombre << " of variable: " << objetoNombre;
		cerr << "\" on line " << line_num << endl;
		exit(-1);
	}
	
	*/
}

void accion_1_llamada_proc_no_predicado(string objetoNombre, string metodoNombre) {
	// Verificar que el procedimiento exista como tal en el Dir. de procs
	/*	

	bool existeMetodo = dirProcedimientos.checaPredicado(objetoNombre);
	int estructuraVariable = dirProcedimientos.checaEstructura(objetoNombre);
		
	// 1 = funciones, 0 = variable, 2 = objeto
	cout << "NOmbre objeto: " << objetoNombre << " metodoNombre: "<<  metodoNombre<<  " existePredicado: " << existePredicado << " estructuraVariable: " << estructuraVariable << endl;
	if (existePredicado == false && estructuraVariable != 1) { 
		cerr << "ERROR: Method not found:  \"" << metodoNombre << " of variable: " << objetoNombre;
		cerr << "\" on line " << line_num << endl;
		exit(-1);
	}
	*/

	
}

void accion_2_llamada_proc() {

	// Generar accipon: Era tamaño (expansion del reagistro de activacion, de acuerdo a tamaño definido )
	// inicializar contador de parametros k = 1;

	indexParametro = 0;
	
	// Si es una variable o funcion de un objeto, como hago un era de un obj de la direccion del objeto
	if ( metodo ) {
		int direccion = dirProcedimientos.buscaDireccion(objetoNombre);
		//cout << "Metodo nombre: " << metodoNombre  << " objetoNombre: " << objetoNombre << " metodo: " << metodo << endl;
		Cuadruplo cuadruploTemp = Cuadruplo("eraObj", to_string(direccion), "" , "");
		cuadruplos.push_back( cuadruploTemp );

		int tipoObjeto = dirProcedimientos.checaTipo(objetoNombre);
		int bloqueMetodo = dirProcedimientos.buscaBloque(dirProcedimientos.nombreTipo(tipoObjeto), metodoNombre);
		//cout << "tipo objeto: "<< tipoObjeto<< " nombre: " <<  dirProcedimientos.nombreTipo(tipoObjeto) <<  " objetoNombre: " << objetoNombre << endl; 
		cuadruploTemp = Cuadruplo("era", to_string(bloqueMetodo), "" , "");
		cuadruplos.push_back( cuadruploTemp );

	} else {

		// Este es un era normal de funcion
		int bloqueMetodo = dirProcedimientos.buscaBloque(objetoNombre);
		Cuadruplo cuadruploTemp = Cuadruplo("era", to_string(bloqueMetodo), "" , "");
		cuadruplos.push_back( cuadruploTemp );	
	}
	
}

void accion_3_llamada_proc() {
	// Argumento ? pop de pilaOperandos, tipoArg = pop.Pilatipos
	// Verificar tipo de argumento contra el parametro k 
	// Generar PARAMETRO, Argumento, parametro k 

	int tipo = pilaTipos.top();
	pilaTipos.pop();
	//TODO Aqui truena porque el checa argumento esta esperando algo antes, pero en este caso es solo una funcion
	bool concuerdaTipo = dirProcedimientos.checaArgumentoTipo(tipo);
	
	if ( concuerdaTipo == false ) {
		cerr << "Wrong argument: on line " << line_num << endl;
		exit(-1);
	}


	int argument = pilaOperandos.top();
	pilaOperandos.pop();

	Cuadruplo cuadruploTemp = Cuadruplo("param", to_string(argument), to_string(indexParametro++), "");
	cuadruplos.push_back( cuadruploTemp );


	
}

void accion_4_llamada_proc() {
	// K = K + 1, apuntar al siguiente parametro
	indexParametro++;

	
}

void accion_5_llamada_proc() {
	/*
	// Verificar que el ultimo parametro apunte a nulo ( en nuestro caso checar el size del vector de params contra k )
	bool completezPredicado = dirProcedimientos.checaCompletezPred(true);

	if ( completezPredicado == false ) {


		cerr << "Faltan parametros en linea " << line_num << endl;
		exit(-1);

	
	}
	*/
	
}

void accion_6_llamada_proc(string nombreProc) {
	// Generar GOSUB , nombre proc, dir de inicio
	
	

	//cout << "Metodo nombre: " << metodoNombre  << " objetoNombre: " << objetoNombre << " metodo: " << metodo << endl;
	// solo hacer esto si es una funcion o objeto

	int estructura = dirProcedimientos.checaEstructura(nombreProc);
	if ( estructura != 0 ) {


		if ( metodo  ) { 

			int tipoObjeto = dirProcedimientos.checaTipo(objetoNombre);				
			int bloqueMetodo = dirProcedimientos.buscaBloque(dirProcedimientos.nombreTipo(tipoObjeto), metodoNombre);
			Cuadruplo cuadruploTemp = Cuadruplo("gosub", to_string(bloqueMetodo), to_string(cuadruplos.size()) , "");
			cuadruplos.push_back( cuadruploTemp );	

		} else {


			int direccionVariable = dirProcedimientos.buscaDireccion(nombreProc);
			int tipoVariable = dirProcedimientos.checaTipo(nombreProc);
			
			pilaOperandos.push(direccionVariable);
			pilaTipos.push(tipoVariable);


			int bloqueMetodo = dirProcedimientos.buscaBloque(metodoNombre);
			Cuadruplo cuadruploTemp = Cuadruplo("gosub", to_string(bloqueMetodo), to_string(cuadruplos.size()) , "");
			cuadruplos.push_back( cuadruploTemp );	
		}
	}
	

	
}



void printCuboSemantico() {
	
	for (int i = 0; i < 4; i++ ) {
		for (int j = 0; j < 4; j++ ) {

			for (int k = 0; k < 13; k++ ) {
				printf("%d, ", cuboSemantico[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
		printf("\n");
	}
}


int getIndexOperador(string operador) {
	if ( operador == "+")
			return 0;
	else if ( operador == "-")
			return 1;
	else if ( operador == "*")
			return 2;
	else if ( operador == "/")
			return 3;
	else if ( operador == "==")
			return 4;
	else if ( operador == "!=")
			return 5;
	else if ( operador == ">")
			return 6;
	else if ( operador == "<")
			return 7;
	else if ( operador == "=")
			return 8;
	else if ( operador == ">=")
			return 9;
	else if ( operador == "<=")
			return 10;
	else if ( operador == "||")
			return 11;
	else if ( operador == "&&")
			return 12;	
	else return -1;

}

int getSiguienteDireccion(int tipo, bool constante, bool global, bool temporal, bool objeto, bool funcion) {

	
	if ( constante) {
		return offsetConstantes[tipo]+ indexConstantes[tipo]++;

	} else if ( temporal ) {
		return offsetTemporales[tipo]+ indexTemporales[tipo]++;
	
	} else if ( objeto ) {
		return offsetDirObjetos[tipo]+ indexDirObjetos[tipo]++;

	}  else if ( funcion ) {
		return offsetDirFunciones[tipo]+ indexDirFunciones[tipo]++;
	}
	else if ( global ) {
		return offsetGlobales[tipo]+ indexGlobales[tipo]++;
		
	}

	return -1;

}

string getTipoVariable(int tipo ) {
	switch (tipo) {
		case 0:
			return "bandera";
			break;
		case 1:
			return "entero";
			break;
		case 2: 
			return "decimal";
			break;
		case 3:
			return "texto";
			break;
		case 4:
			return "vacio";
			break;

		return "vacio";
	}

}

int getIndexTipoVariable(string nombre ) { 
	if ( nombre == "bandera") return 0;
	else if (nombre == "entero") return 1;
	else if ( nombre == "decimal") return 2;
	else if (nombre == "texto" ) return 3;
	else return -1 ;
}

void printCuadruplos() { 
	for (int i = 0; i < cuadruplos.size(); i++ ) {

		cout << i << " \t \t" << cuadruplos[i].getOp() << ", \t\t" << cuadruplos[i].getIzq() << ", \t\t" << cuadruplos[i].getDer() << ", \t\t" << cuadruplos[i].getRes() << endl ;
	}
}

void rellenar(int fin, int cont) {

	
	cuadruplos[fin].setRes(to_string(cont));

}


template <typename T> string to_string(T value)
    {
      //create an output string stream
      std::ostringstream os ;

      //throw the value into the string stream
      os << value ;

      //convert the string stream into a string and return
      return os.str() ;
    }



/** 
	getScope
	Funcion que apartir de una direccion regresa el scope en el que se encuentra
	@param dir direccion a buscar
	@return el scope en el que se encuentra la direccion.
**/
int getScope(int dir){

	if(dir >= OFF_LOWER_LIMIT && dir < OFF_BAND_TEMP){
		return _GLOBAL;
	}else if(dir >= OFF_BAND_TEMP && dir < OFF_BAND_CONST){
		return _TEMPORAL;
	}else if(dir >= OFF_BAND_CONST && dir < OFF_BAND_DIR_OBJ){
		return _CONSTANTE;
	}else if(dir >= OFF_BAND_DIR_OBJ && dir <= OFF_BAND_DIR_FUNCION){
		return _OBJETO;
	}else if(dir >= OFF_BAND_DIR_FUNCION && dir <= OFF_UPPER_LIMIT){
		return _FUNCION;
	}else {
		return _ERROR;
	}
}

/**
	getTipoDireccion
	Recibe una direccion y un scope y regresa el tipo de dato de esta direccion para leer el objeto 
	@param direccion representa la direccion a analizar, ejemplo 16500
	@param scope representa el scope en el que se encuentra la direccion
	@return el tipo de variable que representa esta direccion,0 bandera, 1 entero, 2 decimal 3 texto

**/
int getTipoDireccion ( int dir, int scope ) {
	int tipoDireccion = -1 ;

    switch (scope) {
        case _GLOBAL:
                tipoDireccion = floor( ( dir - OFF_BAND_GLOBAL  )/ 1000 ) ; 
        break;
        case _TEMPORAL: 
                tipoDireccion = floor( ( dir - OFF_BAND_TEMP  )/ 1000 ) ;
        break;
        case _CONSTANTE: 
                tipoDireccion = floor( ( dir - OFF_BAND_CONST  )/ 1000 ) ; 
        break;
        case _FUNCION:
                
                tipoDireccion = floor( ( dir - OFF_BAND_DIR_FUNCION  )/ 1000 ) ; 
                

        break;
        case _OBJETO:

                tipoDireccion = floor( ( dir - OFF_BAND_DIR_OBJ  )/ 1000 ) ; 
        break;

    }
	return tipoDireccion; 

}

/**
        getOperandoIndex
        Funcion que regresa un entero dependiendo del operador que recibe.
        @param operador, operador a buscar
        @return un entero definido como constante global que se usara para las operaciones
**/
int getOperandoIndex(string operador){

    if ( operador == "+") { return _PLUS; }
    if ( operador == "-") { return _MINUS; }
    if ( operador == "*") { return _TIMES; }
    if ( operador == "/") { return _SLASH; }
    if ( operador == "==") { return _EQLEQL; }
    if ( operador == "!=") { return _NEQ; }
    if ( operador == ">") { return _GTR; }
    if ( operador == "<") { return _LSS; }
    if ( operador == "=") { return _EQL; }
    if ( operador == ">=") { return _GTROEQL; }
    if ( operador == "<=") { return _LSSOEQL; }
    if ( operador == "||") { return _OR; }
    if ( operador == "&&") { return _AND; }
    if ( operador == "lee") { return _LEESYM; }
    if ( operador == "muestra") { return _MUESTRASYM; }
    if ( operador == "gotoF") { return _GOTOF; }
    if ( operador == "gotoT") { return _GOTOT; }
    if ( operador == "goto") { return _GOTO; }
    if ( operador == "era") { return _ERA; }
    if ( operador == "gosub") { return _GSUB; }
    if ( operador == "retorno") { return _RETURN; }
    if ( operador == "param") { return _PARAM; }
    if ( operador == "ver") { return _VER; }
    if ( operador == "end") { return _END; }
    if ( operador == "saltolinea") { return _SALTOLINEA; }
    return - 1;
}



/**
    pideEntero
    Metodo que ependiendo del scope regresa el valor del entero que se pide
    @param dir, direccion del entero en cuadruplo
    @param scope, scope de la variable a conseguir
    @return el valor del entero conseguido en memoria
**/
int pideEntero (int dir) { 
    int scope = getScope(dir);
    int valor = -1;
    switch (scope) {
        case _GLOBAL:
                valor =  memoria.pideEntero( dir - OFF_ENT_GLOBAL );
        break;
        case _TEMPORAL: 
                valor =  memoria.pideEnteroTemp( dir - OFF_ENT_TEMP );
                
        break;
        case _CONSTANTE: 
        		valor =  atoi(constantesEnteras[dir- OFF_ENT_CONST ].valor.c_str());
                
        break;
        case _FUNCION:
                valor =  memoria.pideEnteroLoc(  memoria.pideDirEnteroFunc( dir - OFF_ENT_DIR_FUNCION ));

        break;
        case _OBJETO: {
                valor =  memoria.pideEnteroObj(  memoria.pideDirEnteroObj( dir - OFF_ENT_DIR_OBJ ));
                
        }				
        break;

    }
    return valor;
}

/**
    pideBandera
    Metodo que ependiendo del scope regresa el valor del bandera que se pide
    @param dir, direccion del bandera en cuadruplo
    @param scope, scope de la variable a conseguir
    @return el valor de la bandera conseguido en memoria
**/
bool pideBandera (int dir) { 

    int scope = getScope(dir);
    bool valor = false;
    switch (scope) {
        case _GLOBAL:
                valor =  memoria.pideBandera( dir - OFF_BAND_GLOBAL );
        break;
        case _TEMPORAL: 
                valor =  memoria.pideBanderaTemp( dir - OFF_BAND_TEMP );
                
        break;
        case _CONSTANTE: {

        		string val =  constantesBandera[dir- OFF_BAND_CONST ].valor;
        		valor = val == "falso" ? 0 : 1 ;
        }

        break;
        case _FUNCION:
                
                valor =  memoria.pideBanderaLoc(  memoria.pideDirBanderaFunc( dir - OFF_BAND_DIR_FUNCION ));
        break;
        case _OBJETO: 

                valor =  memoria.pideBanderaObj(  memoria.pideDirBanderaObj( dir - OFF_BAND_DIR_OBJ ));
                
        break;

    }
    return valor;
}

/**
    pideTexto
    Metodo que ependiendo del scope regresa el valor del texto  que se pide
    @param dir, direccion del texto en cuadruplo
    @param scope, scope de la variable a conseguir
    @return el valor de la texto conseguido en memoria
**/
string pideTexto (int dir) { 

    int scope = getScope(dir);
    string valor = "";
    switch (scope) {
        case _GLOBAL:
                valor =  memoria.pideTexto( dir - OFF_TEXT_GLOBAL );
        break;
        case _TEMPORAL: 
                valor =  memoria.pideTextoTemp( dir - OFF_TEXT_TEMP );
                
        break;
        case _CONSTANTE: 
        		valor =  constantesTexto[dir- OFF_TEXT_CONST ].valor;
        break;
        case _FUNCION:
                
                valor =  memoria.pideTextoLoc(  memoria.pideDirTextoFunc( dir - OFF_TEXT_DIR_FUNCION ));
        break;
        case _OBJETO:

                valor =  memoria.pideTextoObj(  memoria.pideDirTextoObj( dir - OFF_TEXT_DIR_OBJ ));
                
        break;

    }
    return valor;
}

/**
    pideDecimal
    Metodo que ependiendo del scope regresa el valor del decimal que se pide
    @param dir, direccion del decimal en cuadruplo
    @param scope, scope de la variable a conseguir
    @return el valor de la decimal conseguido en memoria
**/
double pideDecimal (int dir) { 

    int scope = getScope(dir);
    double valor = -1.0;
    switch (scope) {
        case _GLOBAL:
                valor =  memoria.pideDecimal( dir - OFF_DEC_GLOBAL );
        break;
        case _TEMPORAL: 
                valor =  memoria.pideDecimalTemp( dir - OFF_DEC_TEMP );

        break;
        case _CONSTANTE: 
        		valor =  atof(constantesDecimales[dir- OFF_DEC_CONST ].valor.c_str());
      
        break;
        case _FUNCION:
                
                valor =  memoria.pideDecimalLoc(  memoria.pideDirDecimalFunc( dir - OFF_DEC_DIR_FUNCION ));
        break;
        case _OBJETO:

                valor =  memoria.pideDecimalObj(  memoria.pideDirDecimalObj( dir - OFF_DEC_DIR_OBJ ));
                
        break;

    }
    return valor;
}


/**
    guardaEntero
    Metodo que dependiendo del scope guarda la variable entera en la memoria correspondiente
    @param dir, direccion del entero en cuadruplo
    @param scope, scope de la variable a guardar
**/
void guardaEntero (int dir, int valor) { 

    int scope = getScope(dir);
    switch (scope) {
        case _GLOBAL:
                memoria.guardaEntero( dir - OFF_ENT_GLOBAL , valor );
        break;
        case _TEMPORAL: 
        		
                memoria.guardaEnteroTemp( dir - OFF_ENT_TEMP , valor );

        break;
        case _CONSTANTE: 
                memoria.guardaEntero( dir - OFF_ENT_CONST , valor ); 
        break;
        case _FUNCION:
                memoria.guardaEnteroLoc(  memoria.pideDirEnteroFunc( dir - OFF_ENT_DIR_FUNCION), valor );
        break;
        case _OBJETO:
                memoria.guardaEnteroObj(  memoria.pideDirEnteroObj( dir - OFF_ENT_DIR_OBJ), valor );
        break;

    }
}

/**
    guardaBandera
    Metodo que dependiendo del scope guarda la variable booleana en la memoria correspondiente
    @param dir, direccion del booleana en cuadruplo
    @param scope, scope de la variable a guardar
**/
void guardaBandera (int dir, bool valor) { 

    int scope = getScope(dir);
    switch (scope) {
        case _GLOBAL:
                memoria.guardaBandera( dir - OFF_BAND_GLOBAL , valor );
        break;
        case _TEMPORAL: 
                memoria.guardaBanderaTemp( dir - OFF_BAND_TEMP , valor );
        break;
        case _CONSTANTE: 
                memoria.guardaBandera( dir - OFF_BAND_CONST , valor ); 
        break;
        case _FUNCION:
                memoria.guardaBanderaLoc(  memoria.pideDirBanderaFunc( dir - OFF_BAND_DIR_FUNCION), valor );
        break;
        case _OBJETO:
                memoria.guardaBanderaObj(  memoria.pideDirBanderaObj( dir - OFF_BAND_DIR_OBJ), valor );
        break;

    }
}

/**
    guardaDecimal
    Metodo que dependiendo del scope guarda la variable decimal en la memoria correspondiente
    @param dir, direccion del decimal en cuadruplo
    @param scope, scope de la variable a guardar
**/
void guardaDecimal (int dir, double valor) { 

    int scope = getScope(dir);

    switch (scope) {
        case _GLOBAL:
                memoria.guardaDecimal( dir - OFF_DEC_GLOBAL , valor );
        break;
        case _TEMPORAL: {
                memoria.guardaDecimalTemp( dir - OFF_DEC_TEMP , valor );        
        }
        break;
        case _CONSTANTE: 
                memoria.guardaDecimalTemp( dir - OFF_DEC_CONST , valor ); 
        break;
        case _FUNCION:
                memoria.guardaDecimalLoc(  memoria.pideDirDecimalFunc( dir - OFF_DEC_DIR_FUNCION), valor );
        break;
        case _OBJETO:
                memoria.guardaDecimalObj(  memoria.pideDirDecimalObj( dir - OFF_DEC_DIR_OBJ), valor );
        break;

    }
}



/**
    guardaTexto
    Metodo que dependiendo del scope guarda la variable texto en la memoria correspondiente
    @param dir, direccion del texto en cuadruplo
    @param scope, scope de la variable a guardar
**/
void guardaTexto (int dir, string valor) { 

    int scope = getScope(dir);

    switch (scope) {
        case _GLOBAL:
                memoria.guardaTexto( dir - OFF_TEXT_GLOBAL , valor );
        break;
        case _TEMPORAL: 
                memoria.guardaTextoTemp( dir - OFF_TEXT_TEMP , valor );
        break;
        case _CONSTANTE: 
                memoria.guardaTexto( dir - OFF_TEXT_CONST , valor ); 
        break;
        case _FUNCION:
                memoria.guardaTextoLoc(  memoria.pideDirTextoFunc( dir - OFF_TEXT_DIR_FUNCION), valor );
        break;
        case _OBJETO:
                memoria.guardaTextoObj(  memoria.pideDirTextoObj( dir - OFF_TEXT_DIR_OBJ), valor );
        break;

    }
}




/**
 * plus_op
 * Funcion utilizada para llevar a cabo la suma de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void plus_op(Cuadruplo current){

    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    int iRes;
    double dRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i+d==2){
        iRes = pideEntero(dirIzq) + pideEntero(dirDer);
        guardaEntero(dirRes,iRes);
        return;

    } else if (i+d==4) {

    	dRes = pideDecimal(dirIzq) + pideDecimal(dirDer);    	

    } else if (i==2){


        dRes = pideEntero(dirDer) + pideDecimal(dirIzq);
    }
    else{
      dRes = pideDecimal(dirDer) + pideEntero(dirIzq);
    }
    guardaDecimal(dirRes,dRes);
    
}

/**
 * minus_op
 * Funcion utilizada para llevar a cabo la resta de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void minus_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    int iRes;
    double dRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i+d==2){
        iRes = pideEntero(dirIzq) - pideEntero(dirDer);
        guardaEntero(dirRes,iRes);
        return;
    } else  if (i+d==4){
        dRes = pideDecimal(dirIzq) - pideDecimal(dirDer);

    } else  if (i==2){
        dRes = pideDecimal(dirIzq) - pideEntero(dirDer);
    }
    else{
        dRes = pideEntero(dirIzq) - pideDecimal(dirDer);
    }
    guardaDecimal(dirRes,dRes);
}

/**
 * times_op
 * Funcion utilizada para llevar a cabo la multiplicacion de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void times_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    int iRes;
    double dRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));

    if (i+d==2){

        iRes = pideEntero(dirIzq) * pideEntero(dirDer);
        guardaEntero(dirRes,iRes);
        return;
    } else if (i+d==4){
        dRes = pideDecimal(dirIzq) * pideDecimal(dirDer);
    } else if (i==2){
        dRes = pideDecimal(dirIzq) * pideEntero(dirDer);
    }
    else{
        dRes = pideEntero(dirIzq) * pideDecimal(dirDer);
    }
    guardaDecimal(dirRes,dRes);
}

/**
 * divide_op
 * Funcion utilizada para llevar a cabo la division de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void divide_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    int iRes;
    double dRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i+d==2){
        dRes = pideEntero(dirIzq) / pideEntero(dirDer);
    } else if (i+d==4){
        dRes = pideDecimal(dirIzq) / pideDecimal(dirDer);
    } else if (i==2){
        dRes = pideDecimal(dirIzq) / pideEntero(dirDer);
    }
    else{
        dRes = pideEntero(dirIzq) / pideDecimal(dirDer);
    }

    guardaDecimal(dirRes,dRes);
}

/**
 * equal_op
 * Funcion utilizada para llevar a cabo la operacion logica de == de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void equal_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 6){
        bRes=(pideTexto(dirIzq) == pideTexto(dirDer));
    } else if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) == pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) == pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) == pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) == pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) == pideDecimal(dirDer));
    }
    guardaBandera(dirRes,bRes);
}

/**
 * notequal_op
 * Funcion utilizada para llevar a cabo la operacion logica de != de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void notequal_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 6){
        bRes=(pideTexto(dirIzq) == pideTexto(dirDer));
    } else if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) != pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) != pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) != pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) != pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) != pideDecimal(dirDer));
    }
    guardaBandera(dirRes,bRes);
}

/**
 * more_op
 * Funcion utilizada para llevar a cabo la operacion logica de > de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void more_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) > pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) > pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) > pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) > pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) > pideDecimal(dirDer));
    }

    guardaBandera(dirRes,bRes);
}

/**
 * less_op
 * Funcion utilizada para llevar a cabo la operacion logica de < de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void less_op(Cuadruplo current) {
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) < pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) < pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) < pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) < pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) < pideDecimal(dirDer));
    }
    guardaBandera(dirRes,bRes);
}

/**
 * moreeq_op
 * Funcion utilizada para llevar a cabo la operacion logica de >= de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void moreeq_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) >= pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) >= pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) >= pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) >= pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) >= pideDecimal(dirDer));
    }

    guardaBandera(dirRes,bRes);
}

/**
 * lesseq_op
 * Funcion utilizada para llevar a cabo la operacion logica de <= de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void lesseq_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    int i,d,r;
    bool bRes;
    i=getTipoDireccion(dirIzq,getScope(dirIzq));
    d=getTipoDireccion(dirDer,getScope(dirDer));
    r=getTipoDireccion(dirRes,getScope(dirRes));
    if (i + d == 3){
        if (i==2){
            bRes = (pideDecimal(dirIzq) <= pideEntero(dirDer));
        }
        else{
            bRes = (pideEntero(dirIzq) <= pideDecimal(dirDer));
        }
    } else if (i + d == 0){
        bRes=(pideBandera(dirIzq) <= pideBandera(dirDer));
    } else if (i + d == 2){
        bRes=(pideEntero(dirIzq) <= pideEntero(dirDer));
    } else if (i + d == 4){
        bRes=(pideDecimal(dirIzq) <= pideDecimal(dirDer));
    }

    guardaBandera(dirRes,bRes);
}

/**
 * or_op
 * Funcion utilizada para llevar a cabo la operacion logica de || de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void or_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    bool bRes;
    bRes=(pideBandera(dirIzq) || pideBandera(dirDer));

    guardaBandera(dirRes,bRes);
}

/**
 * and_op
 * Funcion utilizada para llevar a cabo la operacion logica de && de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void and_op(Cuadruplo current){
    int dirIzq = atoi(current.getIzq().c_str());
    int dirDer = atoi(current.getDer().c_str());
    int dirRes = atoi(current.getRes().c_str());
    bool bRes;
    bRes=(pideBandera(dirIzq) && pideBandera(dirDer));

    guardaBandera(dirRes,bRes);
}


/**
 * assign_op
 * Funcion utilizada para llevar a cabo la operacion logica de = de dos operandos
 * @param cuadruplo, representando el cuadruplo actual
 */
void assign_op(Cuadruplo current){
  int dirIzq = atoi(current.getIzq().c_str());
  int dirRes = atoi(current.getRes().c_str());
  int i,r;
  i=getTipoDireccion(dirIzq,getScope(dirIzq));
  r=getTipoDireccion(dirRes,getScope(dirRes));
  switch(r){
    case 0:
      guardaBandera(dirRes,pideBandera(dirIzq));
      break;
    case 1:
      if(i==1) {
     	
        guardaEntero(dirRes,pideEntero(dirIzq));
      }
      else {
      	
        guardaEntero(dirRes,pideDecimal(dirIzq));
      }
      break;
    case 2:
      if(i==1)
        guardaDecimal(dirRes,pideEntero(dirIzq) + 0.0);
      else
        guardaDecimal(dirRes,pideDecimal(dirIzq));
      break;
    case 3:
      guardaTexto(dirRes,pideTexto(dirIzq));

      break;
    default:
      break;
  }
}

/**
 * print_op
 * Funcion utilizada para llevar a cabo la operacion logica de muestra() de una direccion de memoria
 * @param cuadruplo, representando el cuadruplo actual
 */
void print_op(Cuadruplo current){
  int dirRes = atoi(current.getRes().c_str());
  int r;
  r=getTipoDireccion(dirRes,getScope(dirRes));
  switch(r){
    case 0:
      cout << pideBandera(dirRes);
      break;
    case 1:
    cout << pideEntero(dirRes);
      break;
    case 2:
    cout << pideDecimal(dirRes);
      break;
    case 3: {

    	string token = pideTexto(dirRes);
    	if ( getScope(dirRes) == 2) {
			token = token.substr(1,token.size()-2);
    	}

    	cout << token;
    }
      break;
    default:
      break;
  }
}

/**
 * checkType
 * Funcion utilizada para checar si lo que se lee es correcto para enteros o decimales
 * @param type, que es el tipo de variable; var, string que es la variable a probar
 * @return valor buleano para decir si esta correcto el string de entrada
 */
bool checkType(int type, string var){
  bool dot=false;

  //Checa que sea entero valido
  if (type==1){
    if (!isdigit(var[0])){
      if(var[0]!='+'&&var[0]!='-'){
        return false;
      }
    }
    for (int i = 1 ;i < var.size() ;i++){
      if (!isdigit(var[i])){
        return false;
      }
    }
    return true;
  }
//checa que sea un decimal valido
  if (type==2){
    if (!isdigit(var[0])){
      if(var[0]!='+'&&var[0]!='-'){
        if (var[0]=='.')
          dot=true;
        else
          return false;
      }
    }
    for (int i = 1 ;i < var.size() ;i++){
      if (!isdigit(var[i])){
        if (var[i]=='.'&&!dot)
          dot=true;
        else
          return false;
      }
    }
    return true;
  }
}

/**
 * read_op
 * Funcion utilizada para leer contenido del usuario para memoria
 * @param cuadruplo, representando el cuadruplo actual
 * @return valor buleano para decir si se pudo ejecutar la funcion
 */

bool read_op(Cuadruplo current){
  
  string input;
  int r;
  int dirRes = atoi(current.getRes().c_str());
  r=getTipoDireccion(dirRes,getScope(dirRes));
  if (r==0){
    bool b;
    cin >> b;
    guardaBandera(dirRes,b);
    return true;
  }
  cin >> input;
  switch(r){
    case 1:
      if (checkType(1,input)){
        int res = atoi(input.c_str());
        guardaEntero(dirRes,res);
        return true;
      }
      else{
        cout <<"No se pudo leer entero"<<endl;
        return false;
      }
      break;
    case 2:
      if (checkType(2,input)){
        double res = atof(input.c_str());
        guardaDecimal(dirRes,res);
        return true;
      }
      else{
        cout <<"No se pudo leer decimal"<<endl;
        return false;
      }
      break;
    case 3:
      guardaTexto(dirRes,input);
      return true;
      break;
    default:
      return false;
      break;
  }
}


/**
 * indexGOTOF
 * Funcion utilizada para representar el GOTOF
 * @param cuadruplo, representando el cuadruplo actual: @param i, para saber cual era la original
 * @return valor entero que es la direccion del cuadruplo a seguir
 */
int indexGOTOF(int i,Cuadruplo current){
  bool b;
  int dirRes = atoi(current.getRes().c_str());
  int dirIzq = atoi(current.getIzq().c_str());

  b = pideBandera(dirIzq);
  return b ? i : (dirRes-1);//-1 porque al final de la iteracion hara i++
}

/**
 * indexGOTOT
 * Funcion utilizada para representar el GOTOT
 * @param cuadruplo, representando el cuadruplo actual: @param i, para saber cual era la original
 * @return valor entero que es la direccion del cuadruplo a seguir
 */
int indexGOTOT(int i,Cuadruplo current){
	bool b;
	int dirRes = atoi(current.getRes().c_str());
	int dirIzq = atoi(current.getIzq().c_str());
	b = pideBandera(dirIzq);
	return b ?  (dirRes-1) : i;//-1 porque al final de la iteracion hara i++
}

void eraPROC(Cuadruplo current){
    int bloque = atoi(current.getIzq().c_str());
    dirProcedimientos.era(bloque);
}
 
int gosubPROC(int i, Cuadruplo current){
	int bloque = atoi(current.getIzq().c_str());
	pilaSUB.push(i);
	return dirProcedimientos.dameCuadruplo(bloque);
}

int retornoPROC(){

    dirProcedimientos.retorno();
    int top = pilaSUB.top();
    pilaSUB.pop();
    return top;
}




/**
 *  solve
 *  Metodo utilizado como si fuera la virtual machine. 
 */
void solve() {


    for(int i  = 0; i < cuadruplos.size(); i++){
        Cuadruplo current = cuadruplos[i];
        /*
                
        string op;
        string der;
        string izq;
        string res;


        */

        //
        //cout << "Current: " << current.getOp() << " getOpIndex: " <<  getOperandoIndex(current.getOp() ) <<  " Valor de i: " << i << endl;
        switch ( getOperandoIndex(current.getOp() ))  {

            //  +     -     *     /    ==    !=     >     <     =    >=    <=    ||     &&
            case _PLUS    : plus_op(current);   break; // Funcion que hace la suma
            case _MINUS   : minus_op(current);   break; // Funcion que hace la resta
            case _TIMES   : times_op(current);   break; // Funcion que hace la multiplicacion
            case _SLASH   : divide_op(current);   break; // Funcion que hace la division
            case _EQLEQL  : equal_op(current);   break; // Funcion que hace ==
            case _NEQ     : notequal_op(current);   break; // Funcion que hace !=
            case _GTR     : more_op(current);   break; // Funcion que hace >
            case _LSS     : less_op(current);   break; // Funcion que hace <
            case _GTROEQL : moreeq_op(current);   break; // Funcion que hace >=
            case _LSSOEQL : lesseq_op(current);   break; // Funcion que hace <=
            case _OR      : or_op(current);   break; // Funcion que hace ||
            case _AND     : and_op(current);   break; // Funcion que hace &&
            case _MUESTRASYM : print_op(current);   break; // Funcion que el output
            case _SALTOLINEA : cout << endl ;   break; // Funcion que el output
            case _LEESYM  : read_op(current);   break; // Funcion que hace la lectura 
            case _EQL     : assign_op(current);   break; // Funcion que hace la asignacion
			case _GOTO    : i = atoi(current.getRes().c_str()) - 1  ;  break;// -1 para equilibrar el i++
			case _GOTOF   : i = indexGOTOF(i,current);   break;
			case _GOTOT   : i = indexGOTOT(i,current);  break;
			case _ERA 	  : eraPROC(current); break;
		    case _GSUB 	  : i = gosubPROC(i,current)-1; break;
		    case _RETURN  : i = retornoPROC(); break;
		 


        }
        
        //cout << "Despues Valor de i: " << i << endl;
    }
}


